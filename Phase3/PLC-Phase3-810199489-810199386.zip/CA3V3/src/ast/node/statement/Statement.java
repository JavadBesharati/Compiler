package ast.node.statement;

import ast.node.Node;

public abstract class Statement extends Node {

}
