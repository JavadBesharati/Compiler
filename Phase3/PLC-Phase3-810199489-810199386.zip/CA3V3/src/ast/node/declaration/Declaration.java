package ast.node.declaration;

import ast.node.Node;

public abstract class Declaration extends Node {
}