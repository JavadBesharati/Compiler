package ast.node.expression.operators;

public enum BinaryOperator {
    assign, eq, neq, add, sub, mult, div, mod, or, and, gt, gte, lt, lte
}
