package ast.node.expression.operators;

public enum UnaryOperator {
    minus, plus, not
}