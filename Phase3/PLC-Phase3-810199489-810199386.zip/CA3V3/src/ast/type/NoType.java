package ast.type;

public class NoType extends Type {
    @Override
    public String toString() {
        return "noType";
    }
}

