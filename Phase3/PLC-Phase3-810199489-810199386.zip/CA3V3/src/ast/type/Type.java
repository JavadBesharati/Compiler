package ast.type;


public abstract class Type {
    public abstract String toString();
}
