package ast.type.primitiveType;

import ast.type.Type;

public class BooleanType extends Type {
    @Override
    public String toString() {
        return "boolean";
    }
}
