package ast.type.primitiveType;

import ast.type.Type;

public class FloatType extends Type {
    @Override
    public String toString() {
        return "float";
    }
}
