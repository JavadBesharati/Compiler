package compileError;

public abstract class CompileError{
    public abstract String getMessage();
}
