package symbolTable.itemException;

public class ItemNotFoundException extends Exception{
}
