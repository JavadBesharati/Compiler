package symbolTable.itemException;

public class ItemAlreadyExistsException extends Exception{
}
